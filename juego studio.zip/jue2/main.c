#include <stdio.h>
#include <stdlib.h>

int main()
{  int i,j,temp,p=0,q=1,k=1;
   for(i=0;i<4;i++)
   {
       for(j=0;j<k;j++)
       {
           printf("%d ",p);
           temp=p+q;
           p=q;
           q=temp;
       }
       printf("\n");
       k++;
   }
    return 0;
}
