#include <stdio.h>
#include <stdlib.h>

int main()
{
   char str[20];
   int i,j,n,k,p;
   printf("enter string");
   gets(str);
   n=strlen(str);
   for(i=0;i<n;i++)
   {  k=0;
       for(j=0;j<n;j++)
       {
          if(str[i]==str[j])
           {
               k++;
           }
       } //if its repeat then k value greater than 1
         if(k==1)
           {
               printf("%c",str[i]);
           }
   }
    return 0;
}
