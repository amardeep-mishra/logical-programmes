#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i,j=2,k,n;
    printf("enter the range of prime number:\t");
    scanf("%d",&n);
    while(j<=n)
    {
        k=1;
        for(i=2;i<j;i++)
        {
            if(j%i==0)
            {
            k=0;
            }
        }
        if(k)
        {
        printf("%d \t",j);
        }
    j++;
    }

    return 0;
}
