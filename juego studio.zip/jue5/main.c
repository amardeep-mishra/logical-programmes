#include <stdio.h>
#include <stdlib.h>

int main()
{
   int a[10],i,j,n,temp;
   printf("enter n value");
   scanf("%d",&n);
   printf("\nenter number");
   for(i=0;i<n;i++)
   {
       scanf("%d",&a[i]);
   }
   for(i=0;i<n;i++)
   {
       for(j=i+1;j<n;j++)
       {
           if(a[i]<a[j])
           {
               temp=a[i];
               a[i]=a[j];
               a[j]=temp;
           }
       }
   }
   printf("\nAfter sorting");
   for(i=0;i<n;i++)
   {
       printf("%d ",a[i]);
   }

    return 0;
}
