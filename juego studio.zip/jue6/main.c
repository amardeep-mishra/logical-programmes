#include <stdio.h>
#include <stdlib.h>

int main()
{
  int i,k=1,j=1;
  printf("%d ",k);
  for(i=0;i<4;i++)
  {
        k++;
        printf("%d ",k);
        k++;
        printf("%d ",k);
        j++;
        k=k+j;
   }
    return 0;
}
