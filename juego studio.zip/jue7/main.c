#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str[20];
    int i,p,q,n,k,j;
    printf("enter string");
    gets(str);
    n=strlen(str);
    j=n-1;
    printf("enter the number for circular fashion");
    scanf("%d",&k);
    for(i=0;i<k;i++)
    {
        for(p=j;p<n;p++)
        {
            printf("%c",str[p]);
        }
        for(q=0;q<j;q++)
        {
            printf("%c",str[q]);
        }
    j--;
    printf("\n");
    }
    return 0;
}
