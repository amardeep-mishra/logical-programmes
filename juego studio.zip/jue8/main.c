#include <stdio.h>
#include <stdlib.h>

int main()
{
  int i,j,k,l,p,q;
  p=5;
  q=0;
  for(i=0;i<5;i++)
  {
      for(k=0;k<q;k++)
      {
          printf(" ");
      }
      for(j=0;j<p;j++)
      {
          printf("%c",j+65);
      }
      for(k=0;k<q;k++)
      {
          printf(" ");
      }
      for(l=p-1;l>=0;l--)
      {
          printf("%c",l+65);
      }
      p--;
      q++;
      printf("\n");
  }


  return 0;
}
